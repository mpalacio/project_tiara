<?php

require_once(APPPATH . "libraries/html2pdf/html2pdf.class.php");

class PT_HTML2PDF {
    public function __construct()
    {
	$this->ci =& get_instance();
    }
    
    public function s($o)
    {
	$html2pdf = new HTML2PDF();
	
	$html2pdf->writeHTML($o);
	$html2pdf->Output('sample.pdf');
    }
}